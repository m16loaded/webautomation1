package qq;

public class two {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     one gogo=new one("bobo");
	}

}
