package qq;

public class one {
String bobo;
	public one(String bobo) {
		this(bobo,"qwe");
	}
	public one(String bobo,String name) {
		System.out.println(bobo+name);
	}
}
