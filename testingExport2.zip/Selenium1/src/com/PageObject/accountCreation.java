package com.PageObject;

import org.openqa.selenium.WebDriver;

public class accountCreation {

	private WebDriver driver;
	public accountCreation(WebDriver driver){ //constructor
		this.driver=driver;
		
	}
}
