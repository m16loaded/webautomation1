package com.JavaTest;

public class BaseClass {
  public void sum(int i,int j){
	  System.out.println(i+j);
  }
}
