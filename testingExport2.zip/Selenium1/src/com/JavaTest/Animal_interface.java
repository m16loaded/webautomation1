package com.JavaTest;

public interface Animal_interface {

	public void talk();
	
}
