package com.JavaTest;

public abstract class Alien { //usually have one abstract method
	
	public abstract void talk();
	
	public boolean isAlive(){
		return true;
		
	}

}
