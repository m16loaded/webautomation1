package com.SeleniumStudy;

import com.JavaTest.Animal_interface;

public class cat implements Animal_interface {

	@Override
	public void talk() {
	System.out.println("cat mew");
		
	}

}
