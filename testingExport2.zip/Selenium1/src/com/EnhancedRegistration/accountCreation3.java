package com.EnhancedRegistration;

import org.openqa.selenium.WebDriver;

public class accountCreation3 {

	private WebDriver driver;
	public accountCreation3(WebDriver driver){ //constructor
		this.driver=driver;
		
	}
}
