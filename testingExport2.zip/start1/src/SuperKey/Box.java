package SuperKey;

public class Box {
public double calcArea(double length,double weidth){
	System.out.println("Area:"+(length*weidth));
	return (length*weidth);
}
}
