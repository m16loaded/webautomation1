package SuperKey;

public class TestBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     SubBox obj=new SubBox();
     obj.calcVolume(4, 5, 6);
	}

}
