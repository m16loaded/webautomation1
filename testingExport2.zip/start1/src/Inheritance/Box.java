package Inheritance;

public class Box { //a SUPERCLASS in this case

	public void CalcArea(int length,int weidth){
		System.out.println("Area"+(length*weidth));
	}
}
