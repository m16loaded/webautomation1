package start1;

public class complex_RNG {

}
