package roman;

public class romanMain {

	public static void main(String[] args) {
		roman2 roman=new roman2();
		System.out.println(roman.getRoman(801));
		
		System.out.println(roman.convert(801));

	}

}
