package Overloading;

public class BoxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Box a=new Box();
    a.calcArea(4);
    a.calcArea(3.7);
    a.calcArea(4,3);
	}

}
