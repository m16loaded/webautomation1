package constractors;

public class SmallBoxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    SmallBox b=new SmallBox();
    b.calcArea();
    SmallBox c=new SmallBox(2,2);
    c.calcArea();
	}

}
