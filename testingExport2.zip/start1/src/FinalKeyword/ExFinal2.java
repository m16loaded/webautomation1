package FinalKeyword;

public class ExFinal2 extends ExFinal1 {//will throw an error if class ExFinal1 is declared as FINAL

	
	public void methodA(){ //will throw an error if methodA() in ExFinal1 is declared FINAL
		
		System.out.println(pi+"dfsdfsdf");
	}
}
