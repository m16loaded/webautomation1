package FinalKeyword;

public class TestFinal {

	public static void main(String[] args) {


		ExFinal2 a=new ExFinal2();
		a.methodA();

	}

}
