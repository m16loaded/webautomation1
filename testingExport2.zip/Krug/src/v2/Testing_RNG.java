package v2;

public class Testing_RNG {

	public static void main(String[] args) {
		int math;
		for(double i=0;i<2;i++){
		math=(int)Math.floor(18+(Math.random()*18 +1));
		System.out.println(math);
		}
	}

}
