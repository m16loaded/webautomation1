package q;

import org.openqa.selenium.WebDriver;

public class google {
WebDriver driver;

}
